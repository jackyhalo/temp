## Annotation references already precompiled for downloading: 

### Homo sapiens (Human)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0773ed3d5f6b74f35bbd643e1af221c31&authkey=AcRxf8walnGUIEhgI--8CDc

### Gorilla gorilla gorilla (Gorilla)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=03a9a8d26cca14b458007e9c6ee4541f7&authkey=Aag33OX-IjvagRWePhYNF3k


### Pan paniscus (Bonobo)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=03a74e9f6c2594f1e86a31acd8e554621&authkey=AYrgOm8rrAY7hrFYQ03gmTA
### Pan troglodytes (Chimp)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=09c13507ee7414365843de3450aa9ad3e&authkey=AdsLOHA5q2--SbiP2C6Qjpc

### Pongo abelii (Orangutan)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=037168296877942ecb9735f26afcb450a&authkey=AZkU5ib3A0KOiT4KxrhgTGQ

### Nomascus leucogenys (Gibbon)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=068ef6629d31b4fb28100f667050be1d1&authkey=AWEPi3HUmOVD_PPPnkMhdvs

### Macaca mulatta (Rhesus)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=07fededf7468444ba9b863b74316b8504&authkey=Aa6X06J4ExLvKtH8mJ-CESs

### Papio anubis (Baboon)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=03a22a2092c7b46fb93a8fc49cf234720&authkey=Ad_hzH3MUIMh0-9BLoH_Vmw

### Callithrix jacchus (Marmoset)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=077698888fa8d40408df8c979e91146e4&authkey=AeoDYl5a3lKyF-CWgupu6IA

### Carlito syrichta (Tarsier)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0c761313792b64396b87a66a6e04101be&authkey=AZBsjTA5-hXdASOIimxNL4I

### Rattus norvegicus (rat)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0b2cacd8453104b2abb60298863fc4c16&authkey=AZAYeCOsLKuc_ml-QMqBJoQ

### Mus musculus (mouse)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0833653a140eb47f098267d7a23d3b63c&authkey=Ab8aoYC8paqFI2yRabIo7Ok

### Cricetulus griseus (Hamster)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0b0ac3830026f4007958774cbdb421632&authkey=AZnURBxU1PYzUO1yyrcoZ_M

### Cavia porcellus (Guinea pig)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0d27261e6ae9c4402bbc9465addb544de&authkey=Ad1xlk56DNm0StozUWDqCYw

### Heterocephalus glaber (Naked mole-rat)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0ceff76c620884395899bcd385bfaa098&authkey=ATiBTnSjWKqY0zPKQOmM6kU

### Ictidomys tridecemlineatus (Squirrel)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0419ea57bd00548cc94574d8ce9717fcd&authkey=Aa1pkb9R7850Ss3GFmB6GzM

### Ochotona princeps (Pika)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=068d8da8388b74c38943e50237a259a88&authkey=AemP73yDCDiObexIk-DcRVQ

### Oryctolagus cuniculus (Rabbit)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=01b2d69333c97448196cc69b212e92fc9&authkey=ARbwyo0-WJX10nDdXwvNygc

### Ovis aries (Sheep)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0e880ae29a16747bebf5b9afdb5956921&authkey=AYIP0UkTwtVuiul45XA7mYE

### Bos taurus (Cow)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0a58e56dc7cb743299631fec15b72e69d&authkey=AeosGslpVMdvtZa6qtKJBCE

### Sus scrofa (Pig)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0e15d39ac05b24a9b899e7a9dfcf96773&authkey=AYaNWQ9KLlkqq7f2qbWzchc

### Tursiops truncatus (Dolphin)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=08396ad3619a247d695508aee771e3991&authkey=AVKuiimDuoOGVKfGvZcK_ik

### Balaenoptera acutorostrata (Minke whale)	https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0d27ad173ffdb4dcc8a4954f9ba5426eb&authkey=AUdYvbA-_q0lzVEEBlth8V8

### Erinaceus europaeus (Hedgehog)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0633e2d7781ab4aefb59fc03f1347657b&authkey=AXrP4XnyiHQqkC5WOUhhS5w

### Sorex araneus (Shrew)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0399046c56fb246c39630c84db61a23ad&authkey=AWE7pAlGt1TAAUylD4qoE9A

### Canis lupus familiaris (Dog)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=06a45d60105a04796b5e96a9417d86f4c&authkey=AY37yxKX-C5u9DG71tzrFEI

### Mustela putorius furo (Ferret)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0ef4e067d42f241359e2e606b14e0d8f9&authkey=AUW2yr7SM356KpD5uhBNOeM

### Ailuropoda melanoleuca (Panda)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0215799b172f94c909c5251061e317540&authkey=AdE82hkEi1MHl3OL1vY92b8

### Felis catus (Cat)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0203fe1a0c8954879878ef8cabcfe37cf&authkey=AZ32jdZI7FoFU_t8_NFb9o0

### Equus caballus (Horse)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0e7011a73d57545ea8be3c71335b3cf4c&authkey=AWHkBfbzVmwz_HjmQXo8IJU

### Ceratotherium simum (White rhinoceros)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0f836e7106664459bacda6f94dc15e22d&authkey=AVSh1b1dr84q53sLTqD9sRA
### Myotis lucifugus (Microbat)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=03dcc351bbc274cfc8692e5f2b1f5d0f3&authkey=AbjlxSozqu1c-2sRUrTGn7k

### Trichechus manatus (Manatee)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=06448172c574b4b9cbe0d906cf75bc68b&authkey=AX_fEuPmr18NZPEFbcg9nEQ

### Loxodonta africana (Elephant)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0e0146e32fe4745bba50bbede409efddc&authkey=AT8bNP2DhjKysDaGD4Qy-7s

### Dasypus novemcinctus (Armadillo)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0c68adc6b2afc447a9dfe45a1a5eedd49&authkey=AUPTS51dr88E3AMvcZtljrk

### Notamacropus eugenii (Wallaby)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=076db8740d2e34caabb25669fd6297e36&authkey=AWv-dFi1Mm7C0QH9K00WHH4

### Sarcophilus harrisii (Tasmanian devil)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0469dc3788cbb40bab7472ee70a230dc0&authkey=AXA1nDb4QpYeuIJFC-D6mL0

### Monodelphis domestica (Opossum)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=05e9cd2f3891a4761ade95d98aa3ebc78&authkey=Ae_jBKIdBC7HypVTN7S98Rw

### Ornithorhynchus anatinus (Platypus)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=07f0f4ed088844a86afa5db763407699c&authkey=AUFx9yWXHtg1CQc-wfpJ81M

### Taeniopygia guttata (Zebra finch)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0defbf712045f4e7f85b373b0eba4cd1b&authkey=AbieXkq6akbsD8tY1oGctDI

### Melopsittacus undulatus (Budgerigar)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0e0046ab3b1a9458a9a183b45507ea0c3&authkey=AWiCroVnVDQcPENZDX_76VM

### Gallus gallus (Chicken)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0abafb326c4074fe9971d60a26497126c&authkey=AcRw_9ltjRXbdNAfmLRl_gg

### Meleagris gallopavo (Turkey)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0c88e1661f08e4b6d945d87e8120bdf07&authkey=AWlCjj414nXNuNbrNM7mbE4

### Chrysemys picta (Painted Turtle)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0fbd62d91eb4442a88525f89684a74242&authkey=AY3fgBdvPRzWpqqD4yd_Sqw

### Anolis carolinensis (Lizard)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=06986df31c45c4a00a6a2b47ce4ee7af2&authkey=AaE-i58-1fjJeqcDHZUpLLo

### Xenopus laevis (Frog)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0d9b3d45b3bf3483c826c36d2b340f0fd&authkey=AdGZ969RHd1lpwBpm7lsGEQ

### Latimeria chalumnae (Coelacanth)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0be8104aeb59d4ff89909d0c62d0a2f4e&authkey=AasK4DZcbB12a8wB8CNz6Ak

### Tetraodon nigroviridis (Tetraodon)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=06252eaadd5894a3795afce052716fd17&authkey=AWZ9FVt-iphiQFRDzuKoJtA

### Takifugu rubripes (Fugu)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=026501a5c4aa54930a00289acf9691f5f&authkey=AWUaDYW0_VZx-1dy5wnCfdQ

### Gasterosteus aculeatus (Stickleback)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0268db779d3654712b39d5450bac55894&authkey=AQwh0wJeAcvF78JRu4RHddM

### Oryzias latipes (Medaka)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0f5089e2cc47245f28dca1a3f8f75343c&authkey=AV8N2wRviWth_LjhJqpB0zk

### Oreochromis niloticus (Nile tilapia)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0cf791d1d99de4f4c8ed7f8de6d5694f8&authkey=AZZgbe3d1aKb7GDuCDlv81w

### Gadus morhua (Atlantic cod)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=08f5a65a279f34d518cc4017cb04fe469&authkey=ASMQLIwmWReD_bVW922N0Io

### Danio rerio (Zebrafish)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=07d3448d6cd29485498e70f8f067a619d&authkey=Aa1-VjshX-GKLZI7limHFIo

### Callorhinchus milii (Elephant shark)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=053976e5c17b9435982d22223b9389eba&authkey=ASL1VUPU4Ol2PskRXpj94t4

### Petromyzon marinus (Lamprey)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=013a1f7a5585b462b801f1cfe3faf2cdd&authkey=AVN94xcHd1_Aa2ofYovsw8Q

### Strongylocentrotus purpuratus (Sea urchin)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0840567689dbe4ff49852c8744056f172&authkey=AWhmaQmPgN5fuB1RXlKc69U

### Drosophila melanogaster (Drosophila)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=06d15ec2032e141648ce4eedd413b0e0c&authkey=ARejQLC8ofAhQq9IwwoB0Pw

### Anopheles gambiae (Mosquito)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=003bfc542d06b42edb24a94969bb12b36&authkey=AdgdWQ5emWRWTYvXcgPT0Fo

### Pristionchus pacificus (Roundworm)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0877c09c8493b47e9b9fb6c2c0bdc6015&authkey=AQJrbZlyZz9MDnPB9uYxMYE

### Caenorhabditis elegans (Nematode)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0cffdc7d5a3844567bc5303adca47fb81&authkey=AdA1jCVLRJkz2k8oSVU-pCI

### Saccharomyces cerevisiae (Yeast)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0a974d08ffcb842dea8d18462dcfaf2f4&authkey=AQ6wsr9hNwVfCfqvuScKStE

### Zea mays (Corn)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0abdce07adf9449e89bdcb89d4d4609a4&authkey=AViNEp3y6Y4hNBYSEuW_sYg

### Sorghum bicolor (Sorghum)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0335fb9b05a024e61819c04db7ffd2a51&authkey=AdMT31NWtny7F1NzJNn3zZI

### Oryza sativa (Rice)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0510818bde4a342868928f982420dd07c&authkey=ASfslUL0BX2HYew7xrw2x1A

### Arabidopsis thaliana (Arabidopsis)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=08ec312d8fc7d4211952170468dfbb202&authkey=AeVag9p4ifZJG58C5UbXstE

### Glycine max (Soybean)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=079974655bb2e4f62b669c3d1701fffeb&authkey=AWVriz_LNaTMDsBjbMXDS60

### Escherichia coli (E.coli)

https://ncrnainfo-my.sharepoint.com/personal/sports_ncrna_info/_layouts/15/guestaccess.aspx?docid=0645cc2a0024d41fdba5be31a17bd5374&authkey=AaR4ui2QEXqh2-SpOIxaUik
